package com.example.cinemaproject

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.DatePicker
import android.widget.NumberPicker
import android.widget.Spinner
import android.widget.TextSwitcher
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.view.get
import org.w3c.dom.Text
import java.lang.StringBuilder

class GetTicketsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_get_tickets)

        val childBtn = findViewById<Button>(R.id.childBtn)
        val adultBtn = findViewById<Button>(R.id.adultBtn)
        val buyNowBtn = findViewById<Button>(R.id.buyNowBtn)
        val amountOfTickets = findViewById<NumberPicker>(R.id.amountNumberPicker)
        val calenderDatePicker = findViewById<DatePicker>(R.id.calenderDatePicker)
        val theaterSpinner = findViewById<Spinner>(R.id.theaterSpinner)
        val totalCostTextView = findViewById<TextView>(R.id.totalCostTextView)
        val coinType = getString(R.string.coinType)
        val totalCost = getString(R.string.totalCost)

        childBtn.setOnClickListener {
            childBtn.isActivated = true
            adultBtn.isActivated = false
            childBtn.setBackgroundColor(ContextCompat.getColor(this,R.color.cyan))
            adultBtn.setBackgroundColor(ContextCompat.getColor(this,R.color.white))

            val finalString = when (coinType) {
                "$" -> totalCost + ("${amountOfTickets.value*10}") + coinType
                else -> totalCost + ("${amountOfTickets.value * 30}") + coinType
            }

            totalCostTextView.text = finalString
            buyNowBtn.isEnabled = true
            buyNowBtn.alpha=1f
        }

        adultBtn.setOnClickListener {
            adultBtn.isActivated = true
            childBtn.isActivated = false
            adultBtn.setBackgroundColor(ContextCompat.getColor(this,R.color.cyan))
            childBtn.setBackgroundColor(ContextCompat.getColor(this,R.color.white))

            val finalString = when (coinType) {
                "$" -> totalCost + ("${amountOfTickets.value*15}") + coinType
                else -> totalCost + ("${amountOfTickets.value * 45}") + coinType
            }

            totalCostTextView.text = finalString
            buyNowBtn.isEnabled = true
            buyNowBtn.alpha=1f
        }

        amountOfTickets.minValue = 1
        amountOfTickets.maxValue = 10

        amountOfTickets.setOnValueChangedListener { picker, oldVal, newVal ->

            if(childBtn.isActivated){
                val cost = when (coinType) {
                    "$" -> "${newVal * 10}"
                    else -> "${newVal * 30}"
                }

                val finalString = totalCost +  cost + coinType
                totalCostTextView.text = finalString
            }

            if(adultBtn.isActivated){
                val cost = when (coinType) {
                    "$" -> "${newVal * 15}"
                    else -> "${newVal * 45}"
                }

                val finalString = totalCost +  cost + coinType
                totalCostTextView.text = finalString
            }
        }

        val theaterArray = resources.getStringArray(R.array.spinner_options)
        val theaterAdapter = ArrayAdapter(this,android.R.layout.simple_spinner_item,theaterArray)
        theaterAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        theaterSpinner.adapter = theaterAdapter

       buyNowBtn.setOnClickListener {

           val intent = Intent(this, MainActivity::class.java)

           val year = calenderDatePicker.year
           val month = calenderDatePicker.month + 1
           val day = calenderDatePicker.dayOfMonth
           val theater = theaterSpinner.selectedItem.toString()
           var age =""
           if(childBtn.isActivated) {age = getString(R.string.child)}
           if(adultBtn.isActivated) {age = getString(R.string.adult)}
           val amount = amountOfTickets.value.toString()
           val cost = totalCostTextView.text.toString()
           val displayDate = getString(R.string.display_date)
           val displayTicketType = getString(R.string.display_ticket_type)
           val displayAmount = getString(R.string.display_amount_of_tickets)

           val DateFormat = when (coinType) {
               "$" -> "$month/$day/$year\n"
               else -> "$day/$month/$year\n"
           }

           val infoText = displayDate + DateFormat +
                         "$theater\n" +
                          displayTicketType + "$age\n" +
                          displayAmount + "$amount\n" +
                         "$cost"

           val builder : AlertDialog.Builder = AlertDialog.Builder(this)
           builder.apply{
               setTitle(R.string.purchase_validation)
               setMessage(infoText)

               setPositiveButton("Yes"){ p0, p1 ->

                   intent.putExtra("infoText", infoText)
                   startActivity(intent)
               }

               setNegativeButton("No"){ p0, p1 ->
                    //do nothing
               }
           }

           builder.create().show()
       }
    }
}