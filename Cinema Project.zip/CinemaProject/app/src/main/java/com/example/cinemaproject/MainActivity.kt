package com.example.cinemaproject

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.app.ActivityOptions
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.transition.Fade
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val viewPurchasesBtn = findViewById<Button>(R.id.viewPurchasesBtn)
        val aboutTheMovieBtn = findViewById<Button>(R.id.aboutTheMovieBtn)
        val photosBtn = findViewById<Button>(R.id.photosBtn)
        val getTicketsBtn = findViewById<Button>(R.id.getTicketsBtn)

        photosBtn.setOnClickListener {
            val dialogBuilder = AlertDialog.Builder(this)
            val dialogView: View = layoutInflater.inflate(R.layout.photos_layout, null)
            val alertDialog = dialogBuilder.setView(dialogView).create()

            alertDialog.window?.attributes?.windowAnimations = R.style.scaling
            alertDialog.show()
        }

        aboutTheMovieBtn.setOnClickListener {
            val dialogBuilder = AlertDialog.Builder(this)
            val dialogView: View = layoutInflater.inflate(R.layout.about_layout,null)
            val alertDialog = dialogBuilder.setView(dialogView).create()

            dialogView.findViewById<TextView>(R.id.aboutTextView).setText(getString(R.string.aboutTheMovieText))
            dialogBuilder.setView(dialogView)
            alertDialog.window?.attributes?.windowAnimations = R.style.fading
            alertDialog.show()
        }

        getTicketsBtn.setOnClickListener {

            val intent = Intent(this,GetTicketsActivity::class.java)
            val options = ActivityOptions.makeCustomAnimation(
                this,
                R.anim.slide_in_right,
                R.anim.slide_out_left
            ).toBundle()

            startActivity(intent, options)
        }

        viewPurchasesBtn.setOnClickListener {

            val infoText = intent.getStringExtra("infoText")
            val dialogBuilder = AlertDialog.Builder(this)
            val dialogView: View = layoutInflater.inflate(R.layout.view_purchases_layout,null)

            dialogView.findViewById<TextView>(R.id.viewPurchasesTextView).text = infoText
            dialogBuilder.setView(dialogView)
            dialogBuilder.show()
        }
    }
}